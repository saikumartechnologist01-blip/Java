class Employee {

 String name;
 String address;
 String role;

public static void main(String args[]){

Employee employee = new Employee();

employee.name = "John Doe";
employee.address = "123 Main St, Anytown, USA";
employee.role = "Software Engineer";

System.out.println("Name: " + employee.name);
System.out.println("Address: " + employee.address);
System.out.println("Role: " + employee.role);
}

}