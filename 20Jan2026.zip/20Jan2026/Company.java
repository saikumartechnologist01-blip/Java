
class Company{

static String companyName="Tech Innovators Inc."; // Method Area
static String companyAddress="456 Innovation Drive, Tech City, USA"; // Method Area

String CEO;

public static void main(String args[]){ // Stack Area

    Company company = new Company(); // Heap Area
     company.CEO = "Alice Smith";

    System.out.println("Company Name: " + companyName);
    System.out.println("Company Address: " + companyAddress);
    System.out.println("CEO: " + company.CEO);

}

   

}