
class Variables{

 static int a=100; 

  public static void main(String args[]){
      Variables.exampleMethod1();
      Variables.exampleMethod2();
  }
  static void exampleMethod1(){
 System.out.println("Value of a: " + Variables.a); // prints 100
 Variables.a=200;

  }

  static void exampleMethod2(){
  System.out.println("Value of a: " + Variables.a); // prints 200
  }

}