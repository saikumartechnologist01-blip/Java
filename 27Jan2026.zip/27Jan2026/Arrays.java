class Arrays{

 public static void main(String args[]){

      int[] pids = {1,2,3,4,5,6,7};

      System.out.println(pids[0]);

      for(int index= 0; index < pids.length; index++){
        System.out.println(pids[index]);
      }

 }

}