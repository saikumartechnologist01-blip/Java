
class A{

}

class Operators{

public static void main(String args[]){

 // Airthmetic Operators
 int a=10;  
 int b=5;  
 System.out.println("Airthmetic Operators:");
    System.out.println("a + b = " + (a + b)); // Addition
    System.out.println("a - b = " + (a - b)); // Subtraction
    System.out.println("a * b = " + (a * b)); // Multiplication
    System.out.println("a / b = " + (a / b)); // Division
    System.out.println("a % b = " + (a % b)); // Modulus

  // Unary Operators 
  int c=10; 
    c++; // Post-Increment 
    ++c;// Pre-Increment
    c--; // Post-Decrement
    --c;// Pre-Decrement
    System.out.println("\nUnary Operators:");
    System.out.println("Value of c after increments and decrements: " + c);

    // Relational Operators - returns boolean values
    System.out.println("\nRelational Operators:");

    int d=20;
    int e=30; 
    System.out.println("d > e: " + (d > e));   // Greater than
    System.out.println("d < e: " + (d < e));   // Less than
    System.out.println("d >= e: " + (d >= e)); // Greater than or equal to
    System.out.println("d <= e: " + (d <= e)); // Less than or equal to
    System.out.println("d == e: " + (d == e)); // Equal to
    System.out.println("d != e: " + (d != e)); // Not equal to

    // Logical Operators - returns boolean values
    System.out.println("\nLogical Operators:");

    String username ="admin";
    String password ="12345";

   boolean result = username.equals("admin") && password.equals("12345");
    System.out.println("Logical AND (&&) result: " + result); // Logical AND

    
   boolean result2 = username.equals("admin") && password.equals("123456");
    System.out.println("Logical AND (&&) result: " + result2); // Logical AND


    String otp ="67890";
    boolean result3 = password.equals("12345") || otp.equals("678905");
    System.out.println("Logical OR (||) result: " + result3); // Logical OR 

    // Assignment Operators
    System.out.println("\nAssignment Operators:");
    int f=10;
    System.out.println("Initial value of f: " + f);
    f += 5; // f = f + 5
    System.out.println("After f += 5: " + f);
    f -= 3; // f = f - 3
    System.out.println("After f -= 3: " + f);
    f *= 2; // f = f * 2
    System.out.println("After f *= 2: " + f);
    f /= 4; // f = f / 4
    System.out.println("After f /= 4: " + f);
    f %= 3; // f = f % 3
    System.out.println("After f %= 3: " + f);


   // Conditional (Ternary) Operator
   System.out.println("\nConditional (Ternary) Operator:");

   String email = "userexample.com"; 
  String emailValidation = email.contains("@") ? "Email is valid" : "Email is invalid";
  System.out.println(emailValidation);


  // Special Operators
  System.out.println("\nSpecial Operators:"); 
   // instanceof Operator 

   Operators obj = new Operators(); 

   boolean isInstance = obj instanceof Operators;
   System.out.println("obj is an instance of Operators: " + isInstance);

   // Arrays - [] Operator
    int[] numbers = {10, 20, 30, 40, 50};
    System.out.println("Array length: " + numbers.length);
    System.out.println("First element: " + numbers[0]);
    System.out.println("Third element: " + numbers[2]);
    System.out.println("Sixth element: " + numbers[5]);
     System.out.println("Second element: " + numbers[1]);

    






}

}