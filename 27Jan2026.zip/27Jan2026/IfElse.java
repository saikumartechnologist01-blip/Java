class IfElse{

   public static void main(String args[]){

      String password ="pass1238"; 

       if(password.length() >= 8){
        System.out.println("Password accepted");
       }
       else{
        System.out.println("Password should be atleast 8 characters");
       }
   }

}