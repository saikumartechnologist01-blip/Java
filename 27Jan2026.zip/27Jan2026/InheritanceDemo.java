
class A1{
   int x=100;
}
class A2 extends A1{
 int x1=200;
}

class A3 extends A2{
 int x2=300;
}

class A4 extends A3{
 int x3=400;
}

class InheritanceDemo{

 public static void main(String args[]){


 }

}