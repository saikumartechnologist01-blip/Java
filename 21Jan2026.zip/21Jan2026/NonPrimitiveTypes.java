
interface Employee{
    String company="ABC Corp"; // String type
    public void login();
    public void logout();
}
class Manager implements Employee{

    public void login(){
        System.out.println("Manager logged in");
    }

    public void logout(){
        System.out.println("Manager logged out");
    }

}
class NonPrimitiveTypes{

    public static void main(String args[]){

               Employee manager= new Manager();  // Interface/ Reference
               manager.login();
               manager.logout();

               Manager mgr= new Manager(); //  Object/ Class




               

    }

}