class Customer{

    String name; 
    int age;
    String city;
    long accountNumber;
    static String bankName = "ABC Bank";
    long accountBalance;

      Customer(String name, int age, String city, long accountNumber, long accountBalance){
            this.name = name;
            this.age = age;
            this.city = city;
            this.accountNumber = accountNumber;
            this.accountBalance = accountBalance;

      }

        void getCustomerDetails(){
           System.out.println(this.name + ", " + this.age + ", " + this.city + ", " + this.accountNumber + ", " + this.accountBalance + ", " + Customer.bankName);
       }



       public static void main(String args[]){

         Customer alice= new Customer("Alice", 30, "New York", 1234567890L, 5000L);
         alice.getCustomerDetails();

         Customer bob= new Customer("Bob", 25, "Los Angeles", 9876543210L, 3000L);
         bob.getCustomerDetails();
        

       }




}

