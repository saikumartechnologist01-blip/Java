class InstanceVariables{

  int a; // non - static variable

  public static void main(String args[]){

    InstanceVariables obj1 = new InstanceVariables();
    obj1.a = 100;
    System.out.println(obj1.a);
     InstanceVariables obj2 = new InstanceVariables();
     System.out.println(obj2.a); // ?

  }

}