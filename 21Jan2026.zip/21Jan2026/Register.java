class Register{

 String firstName;
 String surName; 
 byte day; 
 byte month;
 short year;
 String gender;
 String mobileOrEmail;
 String password;

  Register(String fName, String sName, byte d, byte m, short y, String g, String contact, String pass){
   this.firstName = fName;
   this.surName = sName;
   this.day = d;
   this.month = m;
   this.year = y;
   this.gender = g;
   this.mobileOrEmail = contact;
   this.password = pass;
}

  void displayUserInfo(){

      System.out.println("User Information:");
      System.out.println("First Name: " + this.firstName);
      System.out.println("Surname: " + this.surName);
      System.out.println("Date of Birth: " + this.day + "/" + this.month + "/" + this.year);
      System.out.println("Gender: " + this.gender);
      System.out.println("Mobile or Email: " + this.mobileOrEmail);
      System.out.println("Password: " + this.password);
  }
   


 public static void main(String[] args){

        Register user1 = new Register("John","Doe",(byte)15,(byte)6,(short)1990,"Male","john.doe@example.com","password123");
         user1.displayUserInfo();

 }


}