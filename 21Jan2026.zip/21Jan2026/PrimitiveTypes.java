class PrimitiveTypes{

    public static void main(String args[]){

        byte age = 25;
        short OTP = 1234;
        short year = 2026;
        int pincode = 560001;
        long phoneNumber = 9876543210L;
        long accountNumber = 1234567890123456L;
        float price = 99.99f;
        double distance = 12345.6789;   
        boolean isDone = false;
        char grade = 'A';
        char gender = 'M';
        char size = 'L'; // Large, Small 


    }

}